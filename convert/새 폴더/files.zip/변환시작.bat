@echo off
chcp 65001 > nul
echo.
echo  ╔══════════════════════════════════════╗
echo  ║     MD → HTML 변환기  by convert.py  ║
echo  ╚══════════════════════════════════════╝
echo.

:: Python 설치 확인
python --version > nul 2>&1
if errorlevel 1 (
    echo  [오류] Python이 설치되어 있지 않거나 PATH에 없어요.
    echo         https://www.python.org 에서 설치 후 다시 실행하세요.
    pause
    exit /b 1
)

:: markdown 라이브러리 확인 및 자동 설치
python -c "import markdown" > nul 2>&1
if errorlevel 1 (
    echo  [설치 중] Python markdown 라이브러리를 설치합니다...
    pip install markdown --quiet
    if errorlevel 1 (
        echo  [오류] markdown 설치 실패. 수동으로 설치하세요: pip install markdown
        pause
        exit /b 1
    )
    echo  [완료] markdown 설치 완료
    echo.
)

:: 변환 실행
python convert.py

echo.
echo  변환이 끝났어요. 아무 키나 누르면 창이 닫힙니다.
pause > nul
