#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MD → HTML 일괄 변환기
사용법: python convert.py
       (이 스크립트와 같은 폴더 또는 MD_FOLDER에 지정된 폴더의 .md 파일을 변환)
"""

import os
import re
import glob
import markdown
from pathlib import Path
from datetime import datetime

# ─────────────────────────────────────────────
# ★ 설정 (필요에 따라 수정)
# ─────────────────────────────────────────────
MD_FOLDER   = "./chapters"          # .md 파일이 있는 폴더
OUTPUT_FOLDER = "./html_output"     # 변환된 .html이 저장될 폴더
CSS_PATH    = "../css/style.css"    # HTML에서 참조할 CSS 경로 (상대경로)
SITE_TITLE  = "나의 책"             # 브라우저 탭 / 헤더에 표시될 사이트 제목
SHOW_NAV    = True                  # 이전/다음 챕터 네비게이션 표시 여부
# ─────────────────────────────────────────────

HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>{page_title} — {site_title}</title>
  <link rel="stylesheet" href="{css_path}" />
</head>
<body>

  <header class="site-header">
    <a class="site-title" href="../index.html">{site_title}</a>
  </header>

  <main class="chapter-wrap">

    <article class="chapter-content">
{content}
    </article>

{nav_block}
  </main>

  <footer class="site-footer">
    <p>© {year} {site_title}</p>
  </footer>

</body>
</html>
"""

NAV_TEMPLATE = """\
    <nav class="chapter-nav">
      <div class="nav-prev">{prev_link}</div>
      <div class="nav-next">{next_link}</div>
    </nav>
"""


def slugify(name: str) -> str:
    """파일 이름에서 페이지 제목을 만든다."""
    # chapter_01_intro → Chapter 01 Intro
    name = re.sub(r"[_\-]+", " ", name)
    return name.strip().title()


def extract_title(md_text: str, fallback: str) -> str:
    """마크다운 첫 번째 # 제목을 추출한다."""
    for line in md_text.splitlines():
        line = line.strip()
        if line.startswith("# "):
            return line[2:].strip()
    return fallback


def convert_md_to_html(md_text: str) -> str:
    """마크다운 → HTML 본문 변환 (확장 기능 포함)."""
    extensions = [
        "markdown.extensions.extra",      # 표, 각주, 정의 목록 등
        "markdown.extensions.toc",        # 목차 id 자동 생성
        "markdown.extensions.codehilite", # 코드 하이라이팅
        "markdown.extensions.nl2br",      # 줄바꿈 → <br>
        "markdown.extensions.sane_lists", # 목록 파싱 개선
    ]
    md = markdown.Markdown(extensions=extensions, output_format="html")
    return md.convert(md_text)


def build_nav(files: list, idx: int) -> str:
    if not SHOW_NAV:
        return ""
    prev_link = ""
    next_link = ""
    if idx > 0:
        prev_file = Path(files[idx - 1]).stem + ".html"
        prev_title = slugify(Path(files[idx - 1]).stem)
        prev_link = f'<a href="{prev_file}">← {prev_title}</a>'
    if idx < len(files) - 1:
        next_file = Path(files[idx + 1]).stem + ".html"
        next_title = slugify(Path(files[idx + 1]).stem)
        next_link = f'<a href="{next_file}">{next_title} →</a>'
    return NAV_TEMPLATE.format(prev_link=prev_link, next_link=next_link)


def main():
    md_folder = Path(MD_FOLDER)
    out_folder = Path(OUTPUT_FOLDER)

    if not md_folder.exists():
        print(f"[오류] MD 폴더를 찾을 수 없어요: {md_folder.resolve()}")
        return

    out_folder.mkdir(parents=True, exist_ok=True)

    # 파일 목록 정렬 (파일명 기준 — 앞에 숫자 붙여두면 순서 유지됨)
    md_files = sorted(glob.glob(str(md_folder / "*.md")))

    if not md_files:
        print(f"[알림] {md_folder} 에 .md 파일이 없어요.")
        return

    print(f"\n{'─'*50}")
    print(f"  변환 시작: {len(md_files)}개 파일 발견")
    print(f"  출력 폴더: {out_folder.resolve()}")
    print(f"{'─'*50}")

    year = datetime.now().year

    for idx, md_path in enumerate(md_files):
        md_path = Path(md_path)
        raw = md_path.read_text(encoding="utf-8")

        page_title = extract_title(raw, slugify(md_path.stem))
        body_html  = convert_md_to_html(raw)
        nav_block  = build_nav(md_files, idx)

        # 본문 들여쓰기 (템플릿 가독성용)
        indented_body = "\n".join(
            ("      " + line) if line.strip() else line
            for line in body_html.splitlines()
        )

        final_html = HTML_TEMPLATE.format(
            page_title=page_title,
            site_title=SITE_TITLE,
            css_path=CSS_PATH,
            content=indented_body,
            nav_block=nav_block,
            year=year,
        )

        out_path = out_folder / (md_path.stem + ".html")
        out_path.write_text(final_html, encoding="utf-8")
        print(f"  ✓  {md_path.name:40s} → {out_path.name}")

    print(f"{'─'*50}")
    print(f"  완료! {len(md_files)}개 파일 변환됨")
    print(f"{'─'*50}\n")


if __name__ == "__main__":
    main()
